package com.android.launcher3;

import android.graphics.drawable.Drawable;

/**
 * Created by mcom on 2/3/17.
 */

public class Apps {
    public String name;
    public String pName;
    public String label;
    public Drawable d;
}
