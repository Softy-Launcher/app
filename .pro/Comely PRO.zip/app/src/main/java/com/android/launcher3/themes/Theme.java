package com.android.launcher3.themes;

import javax.inject.Singleton;

@Singleton
public class Theme
{

}
