package com.Softy.Services.GoodHub;

import android.os.Bundle;

/**
 * Created by softy on 6/22/17.
 */

public interface AccountInterface {
    public void onCreate(Bundle savedInstanceState);
    public boolean shouldShowManager();
    public void showManager();
}
