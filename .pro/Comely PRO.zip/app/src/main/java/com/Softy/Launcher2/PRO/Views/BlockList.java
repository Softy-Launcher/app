package com.Softy.Launcher2.PRO.Views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

/**
 * Created by mcom on 3/29/17.
 */

public class BlockList extends ListView{
    public BlockList(Context context) {
        super(context);
    }

    public BlockList(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public BlockList(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public BlockList(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }
}
