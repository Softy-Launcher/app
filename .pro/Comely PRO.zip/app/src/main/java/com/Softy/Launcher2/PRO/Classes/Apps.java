package com.Softy.Launcher2.PRO.Classes;

import android.graphics.drawable.Drawable;

/**
 * Created by mcom on 3/29/17.
 */

public class Apps {
    public String label;
    public String name;
    public String packageName;
    public Drawable mIcon;
}
